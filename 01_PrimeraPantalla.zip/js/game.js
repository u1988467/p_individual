import { clickCard } from "./memory.js";

document.getElementById('co1').addEventListener('click', 
function () { 
    clickCard("co") 
});

document.getElementById('co2').addEventListener('click', 
function () { 
    clickCard("co") 
});

document.getElementById('cb1').addEventListener('click', 
function () {
    clickCard("cb")
});

document.getElementById('cb2').addEventListener('click', 
function () {
    clickCard("cb")
});